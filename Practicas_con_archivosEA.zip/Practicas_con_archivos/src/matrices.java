import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class matrices {
    public static void main(String[] args) {

        try {

            double[][] matrizA = leerMatrizDesdeArchivo("C:\\Users\\vitor\\IdeaProjects\\Practicas_con_archivos\\src\\a.mat");
            double[][] matrizB = leerMatrizDesdeArchivo("C:\\Users\\vitor\\IdeaProjects\\Practicas_con_archivos\\src\\b.mat");

            double[][] producto = multiplicarMatrices(matrizA, matrizB);

            escribirMatrizEnArchivo(producto, "C:\\Users\\vitor\\IdeaProjects\\Practicas_con_archivos\\src\\c.mat");

            imprimirMatriz(producto);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static double[][] leerMatrizDesdeArchivo(String archivo) throws Exception {

        try (DataInputStream input = new DataInputStream(new FileInputStream(archivo))) {

            int filas = input.readByte();
            int columnas = input.readByte();

            double[][] matriz = new double[filas][columnas];

            for (int i = 0; i < filas; i++) {
                for (int j = 0; j < columnas; j++) {
                    matriz[i][j] = input.readDouble();
                }
            }
            return matriz;
        }
    }

    public static double[][] multiplicarMatrices(double[][] matrizA, double[][] matrizB) {

        int filasA = matrizA.length;
        int columnasB = matrizB[0].length;
        int columnasA = matrizA[0].length;


        double[][] producto = new double[filasA][columnasB];

        for (int i = 0; i < filasA; i++) {
            for (int j = 0; j < columnasB; j++) {
                for (int k = 0; k < columnasA; k++) {
                    producto[i][j] += matrizA[i][k] * matrizB[k][j];
                }
            }
        }
        return producto;
    }

    public static void escribirMatrizEnArchivo(double[][] matriz, String archivo) throws Exception {

        try (DataOutputStream escritura = new DataOutputStream(new FileOutputStream(archivo))) {

            escritura.writeByte(matriz.length);
            escritura.writeByte(matriz[0].length);

            for (int i = 0; i < matriz.length; i++) {
                for (int j = 0; j < matriz[0].length; j++) {
                    escritura.writeDouble(matriz[i][j]);
                }
            }
        }
    }

    public static void imprimirMatriz(double[][] matriz) {

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }
}