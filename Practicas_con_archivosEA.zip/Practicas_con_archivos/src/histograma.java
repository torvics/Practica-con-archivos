import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class histograma {

    public static void main(String[] args) {
        String archivoTexto = "C:\\Users\\vitor\\IdeaProjects\\Practicas_con_archivos\\src\\divina_comedia_sp.txt"; // Cambia esto al nombre de tu archivo de texto
        Map<Integer, Integer> histograma = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivoTexto))) {
            String linea;

            while ((linea = br.readLine()) != null) {
                String[] palabras = linea.split("\\s+");

                for (String palabra : palabras) {

                    if (palabra.length() >= 2 && palabra.length() <= 10) {
                        int longitud = palabra.length();
                        histograma.put(longitud, histograma.getOrDefault(longitud, 0) + 1);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (Map.Entry<Integer, Integer> entry : histograma.entrySet()) {
            System.out.printf("Palabras de %d letras:  %d%n", entry.getKey(), entry.getValue());
        }

    }

}